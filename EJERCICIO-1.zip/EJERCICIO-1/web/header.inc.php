<!-- Header -->
<header id="header" class="header">
        <div class="">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-container"><br><br><br><br><br><br><br><br><br><br><br><br>
                            <p class="p-heading p-large" >LA FACULTAD CUENTA CON LAS SIGUIENTES CARRERAS:</p>
                            <h1><span id="js-rotating" style="text-align: center;">MATEMÁTICA, FÍSICA, CIENCIAS QUÍMICA, INFORMÁTICA, BIOLOGÍA, ESTADÍSTICA</span></h1>
                            <br><br><br><br><br><br><br><br><br><br><br><br>
                            <!--<a class="btn-solid-lg page-scroll" href="#intro">DISCOVER</a>-->
                        </div>
                    </div> <!-- end of col -->
                </div> <!-- end of row -->
            </div> <!-- end of container -->
        </div> <!-- end of header-content -->
    </header> <!-- end of header -->
    <!-- end of header -->
